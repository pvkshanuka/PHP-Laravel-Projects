<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class periodtime extends Model
{
    //
}
