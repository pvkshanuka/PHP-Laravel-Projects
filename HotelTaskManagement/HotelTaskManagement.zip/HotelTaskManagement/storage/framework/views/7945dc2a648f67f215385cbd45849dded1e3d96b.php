 <?php $__env->startSection('content'); ?>
<!-- 
<style>
    .loader {
        border: 16px solid #f3f3f3;
        border-radius: 50%;
        border-top: 16px solid #3498db;
        width: 120px;
        height: 120px;
        -webkit-animation: spin 2s linear infinite;
        /* Safari */
        animation: spin 2s linear infinite;
    }
    /* Safari */
    
    @-webkit-keyframes spin {
        0% {
            -webkit-transform: rotate(0deg);
        }
        100% {
            -webkit-transform: rotate(360deg);
        }
    }
    
    @keyframes  spin {
        0% {
            transform: rotate(0deg);
        }
        100% {
            transform: rotate(360deg);
        }
    }
</style>

<div id="loader">
    <br>
    <h3 align="center">Hotel Task Report</h3>
    <br>
    <br>
    <center>
        <div class="loader"></div>
    </center>
</div> -->

<div class="container">


    <br>
    <h3 align="center" style="background-color:lightyellow !important; padding: 5px;">Hotel Task Report</h3>
    <br>
    <table class="table table-striped">
        <thead>
            <tr class="thcolor">
                <th>Task ID</th>
                <th>EMP</th>
                <th>Date</th>
                <th>Venue</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody id="tabledata">
            <!-- <tr>
                <td>id</td>
                <td>date</td>
                <td>venue</td>
                <td>emp</td>
                <td>status</td>
            </tr>
            <tr>
                <td>Mary</td>
                <td>Moe</td>
                <td>Moe</td>
                <td>Moe</td>
                <td>mary@example.com</td>
            </tr>
            <tr>
                <td>July</td>
                <td>Dooley</td>
                <td>july@example.com</td>
                <td>july@example.com</td>
                <td>july@example.com</td>
            </tr> -->
        </tbody>
    </table>
</div>

<script type="text/javascript">
    $(document).ready(function() {

        $.ajax({
            url: "<?php echo e(route('taskreport.viewreport')); ?>",
            method: "GET",
            success: function(data) {

                $('#tabledata').html(data);
                window.print();

            },
            error: function() {
                alert("error");
            }
        })

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>